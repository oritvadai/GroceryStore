
export const environment = {
    production: true
};

export const serverBaseUrl = "http://45.79.248.126:3000/api"
