
export const environment = {
    production: false
};

export const serverBaseUrl = "http://localhost:3000/api"
