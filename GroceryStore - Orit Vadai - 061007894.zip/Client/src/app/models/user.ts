
export class User {

    public constructor(
        public _id?: string,
        public firstName?: string,
        public lastName?: string,
        public username?: string,
        public ID?: number,
        public password?: string,
        public city?: string,
        public street?: string,
        public role?: string) {
    }
}
