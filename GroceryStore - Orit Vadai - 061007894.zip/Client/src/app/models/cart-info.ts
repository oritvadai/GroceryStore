    
export class CartInfo {

    public constructor(
        public _id?: string,
        public date?: Date,
        public hasCarts?: boolean,
        public hasOpenCart?: boolean) {
    }
}
